console.log("Created by @Phani-E650 and @U-C-S");

/*
let car = document.querySelector(".carousel").getElementsByTagName("div");
for (let i = 0; i < car.length; i++) {
  const element = car[i];
  set
  
}
*/
