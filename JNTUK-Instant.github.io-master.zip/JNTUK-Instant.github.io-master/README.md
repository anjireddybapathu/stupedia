# JNTUK-Notes.github.io
![progress](https://img.shields.io/badge/Progress%3A-45%25-red)
<p>Contains Study-Materials for B.E./B.Tech for JNTU-Kakinada affliated Colleges</p>
