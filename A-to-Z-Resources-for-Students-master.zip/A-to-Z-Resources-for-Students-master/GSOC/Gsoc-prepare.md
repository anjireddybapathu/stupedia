🚀 #*Prepare for Google Summer of Code* 

📌 ##Before even thinking about applying to GSoC you 
should be using atleast some open source software and 
must have interest in some sub-field (Machine/Deep learning,
 Artificial Intelligence, etc.) of computer science. You must start preparation before 2-3 months of official GSoC start date.

📌## Head over to previous year’s GSoC Archives (These projects are most likely to come again) and search for the project/organization you would like to contribute to according to your interest.

📌## Use the software as normal user is supposed to and enumerate each and every way of using it.

📌## Align your learning of tech stack and knowledge as required for that project or preferably choose the one that aligns with yours.

📌## Head over to that project’s source code repository, setup the Dev-environment, read the docs and other relevant terial extensively.

📌## Get totally familiar with source code(will be intimidating at first but can get really easy if you do second step thoroughly).

📌## Contact the project lead/Community on given communication channel, ask them doubts, bugs to fix, feature enhancements etc.

📌## Ask them to assign any task to you and Start Contributing.
