# A to Z Resources for Students ![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)

## Index
1. [PHP Basics](#1-python-basics)
2. [Framework](#2-framework)



## 1. PHP Basics
+ <a href = "https://sekolahkoding.com/kelas/belajar-php-dari-dasar">PHP Basics (Bahasa)</a>

## 2. Framework
+ <a href = "https://www.youtube.com/playlist?list=PLFIM0718LjIXU8ul9FiN-owk04cQKtHPw"> Web Programming UNPAS - Codeigniter Basic (Membuat Sistem Login) (Bahasa)</a>
+ <a href = "https://laravel.com/docs">Laravel Documentation</a>
+ <a href = "https://github.com/laravel/laravel">Laravel Github</a>
